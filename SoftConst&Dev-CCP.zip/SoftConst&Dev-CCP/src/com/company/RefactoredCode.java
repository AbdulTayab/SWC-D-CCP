private void confirmReservationButtonActionPerformed(java.awt.event.ActionEvent evt) {
        if (!isDateValid()) return;
        if (!isNameValid()) return;
        if (!isAddressValid()) return;
        if (!isCreditCardValid()) return;

        String reservationMessage = guestHouseChainFacade.makeReservation(
        guestHouseName, startDate, endDate, roomType,
        reserverName, multiLineAddress, creditCardNo
        );

        reservationFeedbackField.setText(reservationMessage);

        if (reservationMessage.startsWith("Confirmed")) {
        setEnabledMakeReservationPanel(false);
        }
        }

private boolean isDateValid() {
        if (startDate == null || endDate == null) {
        reservationFeedbackField.setText("Enter valid dates");
        return false;
        }
        return true;
        }

private boolean isNameValid() {
        if (reserverName.trim().isEmpty()) {
        reservationFeedbackField.setText("Enter valid name");
        customerNameField.requestFocus();
        return false;
        }
        return true;
        }

private boolean isAddressValid() {
        if (address.trim().isEmpty()) {
        reservationFeedbackField.setText("Enter valid address");
        customerAddressTextArea.requestFocus();
        return false;
        }
        return true;
        }

private boolean isCreditCardValid() {
        if (existingAddresses == null && !GuestHouseFacade.isValidCreditCardNumberFormat(creditCardNo)) {
        reservationFeedbackField.setText(GuestHouseFacade.creditCardNumberFormatError(creditCardNo));
        creditCardNumberField.selectAll();
        creditCardNumberField.requestFocus();
        return false;
        }
        return true;
        }


